//
//  lab07App.swift
//  lab07
//
//  Created by User on 2021/5/5.
//

import SwiftUI

@main
struct lab07App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
