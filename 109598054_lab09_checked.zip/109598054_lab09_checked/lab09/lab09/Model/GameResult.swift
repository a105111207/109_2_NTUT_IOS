//
//  GameResult.swift
//  lab09
//
//  Created by User on 2021/5/19.
//

import SwiftUI

enum GameResult {
    case win
    case lose
    case tie
}
